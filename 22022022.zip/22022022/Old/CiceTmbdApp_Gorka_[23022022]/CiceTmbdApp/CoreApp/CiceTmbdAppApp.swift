//
//  CiceTmbdAppApp.swift
//  CiceTmbdApp
//
//  Created by Gorka Ormazabal on 23/2/22.
//

import SwiftUI

@main
struct CiceTmbdAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
