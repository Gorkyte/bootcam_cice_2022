//
//  ContentView.swift
//  CiceTmdbApp
//
//  Created by Jorge Millan on 22/2/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            HomeView()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
