//
//  CiceTmdbAppApp.swift
//  CiceTmdbApp
//
//  Created by Jorge Millan on 22/2/22.
//

import SwiftUI

@main
struct CiceTmdbAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
