//
//  Constants.swift
//  CiceTmdbApp
//
//  Created by Jorge Millan on 23/2/22.
//

import Foundation

struct Constants{
    struct Api{
        static let apiKey: [UInt8] = [37, 65, 15, 89, 76, 43, 98, 125, 7, 94, 7, 91, 67, 37, 67, 88, 95, 79, 123, 100, 120, 90, 92, 85, 91, 65, 112, 67, 94, 12, 27, 121] //a4b45e12e4b87a652657786085463ab7
    }
}
