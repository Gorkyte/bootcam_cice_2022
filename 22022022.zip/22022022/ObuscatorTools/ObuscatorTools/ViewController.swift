//
//  ViewController.swift
//  ObuscatorTools
//
//  Created by Gorka Ormazabal on 23/2/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print(Obfuscator().bytesByObfuscatingString(string: "f290a033176d9ecb617892c9da4bdb8c"))        // Do any additional setup after loading the view.
    }


}

