//
//  TravelAppApp.swift
//  TravelApp
//
//  Created by Gorka Ormazabal on 30/4/22.
//

import SwiftUI

@main
struct TravelAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
