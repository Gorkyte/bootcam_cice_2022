//
//  PeopleCarrousel.swift
//  TravelApp
//
//  Created by Gorka Ormazabal on 15/5/22.
//

import SwiftUI

struct PeopleCarrousel: View {
    
    let title: String
    let dataModel: [PeopleViewModel]
    
    var body: some View {
        VStack (alignment: .leading, spacing: 2) {
            HStack{
                Text(title)
                    .fontWeight(.bold)
                    .padding(.horizontal)
                Rectangle()
                    .fill(Color.green.opacity(0.3))
                    .frame(width: 50, height: 5)
                
            }
            .padding(.bottom,10)
            
            LazyVGrid(columns: Array(repeating: GridItem(), count: 3)) {
                ForEach(self.dataModel){ item in
                    PeopleCell(model: item)
                }
            }
        }
    }
}

struct PeopleCell: View {
    
    let model: PeopleViewModel
    @ObservedObject var imageLoaderVM = ImageLoader()
    
    init (model: PeopleViewModel) {
        self.model = model
        self.imageLoaderVM.loadImage(whit: self.model.profilePathUrl)
    }
    
    var body: some View {
        ZStack{
            if self.imageLoaderVM.image != nil{
                Image(uiImage: self.imageLoaderVM.image!)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                VStack(alignment: .leading, spacing: 5) {
                    Text(self.model.name ?? "")
                        .font(.headline)
                }
            }else {
                Circle()
                    .fill(LinearGradient(gradient: Gradient(colors: [Color.green, Color.clear]),
                                         startPoint: .bottom,
                                         endPoint: .top))
                    .clipShape(Circle())
            }
        }
    }
}

//struct PeopleCarrousel_Previews: PreviewProvider {
//    static var previews: some View {
//        PeopleCarrousel(title: "",
//                        dataModel: PeoplePopularServerModel.stubbedPeoplePopular?.results)
//    }
//}
