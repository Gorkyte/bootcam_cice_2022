//
//  Constants.swift
//  TravelApp
//
//  Created by Gorka Ormazabal on 2/5/22.
//

import Foundation

struct Constants {
    
    struct Api{
        static let apiKey: [UInt8] = [34, 71, 84, 93, 24, 126, 96, 124, 83, 93, 83, 7, 77, 33, 22, 15, 91, 72, 121, 107, 118, 80, 9, 92, 7, 21, 112, 23, 9, 15, 65, 45] //"f290a033176d9ecb617892c9da4bdb8c"
        
    }
    
    static var totalPages = 3
    
    
}


